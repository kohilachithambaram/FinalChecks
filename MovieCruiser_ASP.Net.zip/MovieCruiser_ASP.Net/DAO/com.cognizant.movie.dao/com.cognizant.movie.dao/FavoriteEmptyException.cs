﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.movie.dao {
    public class FavoriteEmptyException:Exception {

        private string _message;

        public FavoriteEmptyException() {

        }

        public FavoriteEmptyException(string _message) {
            this.Message = _message;
        }

        public string Message {
            get {
                return _message;
            }

            set {
                _message = value;
            }
        }

        public override string ToString() {
            return string.Format("{0}", this._message);
        }
    }
}
