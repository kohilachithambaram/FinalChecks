﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.movie.model {
    public class Favorites {
        private List<Movie> _movieList;
        private double _total;

        public Favorites() {

        }

        public Favorites(List<Movie> _movieList, double _total) {
            this.MovieList = _movieList;
            this.Total = _total;
        }

        public double Total {
            get {
                return _total;
            }

            set {
                _total = value;
            }
        }

        public List<Movie> MovieList {
            get {
                return _movieList;
            }

            set {
                _movieList = value;
            }
        }
    }
}
