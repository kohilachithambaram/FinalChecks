﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.movie.model {
    public class Movie {
        private long _id;
        private string _title;
        private float _budget;
        private bool _active;
        private DateTime _dateOfLaunch;
        private string _genre;
        private bool _hasTeaser;

        public Movie() {

        }

        public Movie(long _id, string _title, float _budget, bool _active, DateTime _dateOfLaunch, string _genre, bool _hasTeaser) {
            this.Id = _id;
            this.Title = _title;
            this.Budget = _budget;
            this.Active = _active;
            this.DateOfLaunch = _dateOfLaunch;
            this.Genre = _genre;
            this.HasTeaser = _hasTeaser;
        }

        public long Id {
            get {
                return _id;
            }

            set {
                _id = value;
            }
        }

        public string Title {
            get {
                return _title;
            }

            set {
                _title = value;
            }
        }

        public float Budget {
            get {
                return _budget;
            }

            set {
                _budget = value;
            }
        }

        public bool Active {
            get {
                return _active;
            }

            set {
                _active = value;
            }
        }

        public DateTime DateOfLaunch {
            get {
                return _dateOfLaunch;
            }

            set {
                _dateOfLaunch = value;
            }
        }

        public string Genre {
            get {
                return _genre;
            }

            set {
                _genre = value;
            }
        }

        public bool HasTeaser {
            get {
                return _hasTeaser;
            }

            set {
                _hasTeaser = value;
            }
        }

        public override string ToString() {
            return string.Format("{0,-10}{1,-20}{2,-10}{3,-10}{4,-18}{5,-15}{6}", this._id, this._title, (double)this._budget, 
                                this._active == true ? "Yes" : "No", this._dateOfLaunch.ToString("dd/MM/yyyy"), this._genre, this._hasTeaser == true ? "Yes" : "No");
        }

        public override bool Equals(object obj) {
            if (obj == null) {
                return false;
            }
            else {
                Movie movie = (Movie)obj;
                return (this.Id.Equals(movie.Id));
            }
        }

        public override int GetHashCode() {
            return base.GetHashCode();
        }

    }
}


