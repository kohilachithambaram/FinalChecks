﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;
using com.cognizant.movie.dao;
using com.cognizant.movie.util;

namespace MovieCruiserConsole {

    class FavoritesDaoCollectionImplTest {

        public FavoritesDaoCollectionImplTest() {
            testAddFavoritesItem();
            testRemoveFavoritesItem();
        }

        public static void testAddFavoritesItem() {
            Console.WriteLine("\nAdd new item to favorites");
            FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
            favoritesDao.addFavorite(1, 1001);
            try {
                testGetAllFavoritesItem();
            }
            catch (FavoriteEmptyException e) {
                Console.WriteLine(e);
            }
        }

        public static void testGetAllFavoritesItem() {
            FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
            Favorites favorites = favoritesDao.getAllFavorites(1);
            Console.WriteLine("\nTitle       Active      Budget");
            for (int i = 0; i < favorites.MovieList.Count; i++) {
                Console.WriteLine(favorites.MovieList[i].Title + "     " + favorites.MovieList[i].Active + "     " + (double)favorites.MovieList[i].Budget
                   + "\nBudget  " + favorites.Total);
            }
        }

        public static void testRemoveFavoritesItem() {
            Console.WriteLine("\nRemove data from favorites");
            FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
            favoritesDao.removeFavorite(1, 1001);
            try {
                testGetAllFavoritesItem();
            }
            catch (FavoriteEmptyException e) {
                Console.WriteLine("\n" + e);
            }
        }
    }
}
