﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;
using com.cognizant.movie.dao;
using com.cognizant.movie.util;

namespace MovieCruiserConsole {

    class MovieDaoCollectionImplTest {

        public MovieDaoCollectionImplTest() {
            testGetMovieListAdmin();
            testGetMovieListCustomer();
            testModifyMovie();

        }

        public static void testGetMovieListAdmin() {
            MovieDaoCollectionImpl movieDaoCollection = new MovieDaoCollectionImpl();
            List<Movie> movieList = movieDaoCollection.getMovieListAdmin();
            Console.WriteLine("Menu display for admin");
            Console.WriteLine("{0,-10}{1,-20}{2,-10}{3,-10}{4,-18}{5,-15}{6}", "Id", "Title", "Budget", "Active", "Date Of Launch", "Genre", "Has Teaser");

            foreach (Movie movie in movieList) {
                Console.WriteLine(movie);
            }
        }

        public static void testGetMovieListCustomer() {
            MovieDaoCollectionImpl movieDaoCollection = new MovieDaoCollectionImpl();
            List<Movie> movieList = movieDaoCollection.getMovieListCustomer();
            Console.WriteLine("\nMenu display for customer");
            Console.WriteLine("{0,-10}{1,-20}{2,-10}{3,-10}{4,-18}{5,-15}{6}", "Id", "Title", "Budget", "Active", "Date Of Launch", "Genre", "Has Teaser");
       
            foreach (Movie movie in movieList) {
                Console.WriteLine(movie);
            }
        }

        public static void testModifyMovie() {
            MovieDaoCollectionImpl movieDaoCollection = new MovieDaoCollectionImpl();
            Movie modifiedmenu = new Movie(1002, "Aladdin", 153000000.00f, true, DateUtil.convertToDate("20/12/2022"), "Adventure", true);
            movieDaoCollection.modifyMovie(modifiedmenu);
            testGetMovie();
        }

        public static void testGetMovie() {
            MovieDaoCollectionImpl movieDaoCollection = new MovieDaoCollectionImpl();
            Movie movie = movieDaoCollection.getMovie(1002);
            if (movie != null) {
                Console.WriteLine("\nUpdated Menu");
                Console.WriteLine("{0,-10}{1,-20}{2,-10}{3,-10}{4,-18}{5,-15}{6}", "Id", "Title", "Budget", "Active", "Date Of Launch", "Genre", "Has Teaser");
                Console.WriteLine(movie);
            }
            else {
                Console.WriteLine("\nNo menu found to modify");
            }
        }
    }
}
