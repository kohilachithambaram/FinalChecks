function validate() {

  var title = document.Edit_form.title.value;
  var budget = document.Edit_form.budget.value;
  var dateOfLaunch = document.Edit_form.dateOfLaunch.value;
  var genre = document.Edit_form.genre.value;

  if(title == null || title == "" ) {

    alert('Title is required');
    return false;

  }

  if(title.length<2 || title.length>65) {

    alert('Title should have 2 to 65 characters');
    return false;
  }

  if(isNaN(budget)) {

    alert('Budget has to be a number');
    return false;
 
  }

  if(budget == null || budget == "" ) {

    alert('Budget is required');
    return false;
 
  }

  if(dateOfLaunch == null || dateOfLaunch == "" ) {

    alert('Date Of Launch is required');
    return false;

  }

  var datePattern=/^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:(0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/;
  if(!dateOfLaunch.match(datePattern)) {

    alert('Date Of Launch must be in DD/MM/YYYY format');
    return false;

  }

  if(genre == null || genre == "" ) {

    alert('Select one genre');
    return false;

  }

  else {

    return true;

  }

}

function checkRadio() {

  if(document.getElementById("activeYes").checked==true) {

     alert("Yes Active");

  }

  if(document.getElementById("activeNo").checked==true) {

    alert("Not Active");
  }
}

function checkOption() {

  if(document.getElementById("hasTeaser").checked==true) {

    alert("Teaser available");

  }

  else {

    alert("Teaser not available");
  }
}