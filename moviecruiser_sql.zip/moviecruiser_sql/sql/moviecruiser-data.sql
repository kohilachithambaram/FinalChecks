use moviecruiser;

/*1.View Movie List Admin*/
insert into movie values('Avengers',356000000.00,'Yes','04/26/2020','Action','Yes'),
('Aladdin',183000000.00,'Yes','05/24/2019','Adventure','No'),
('Captain Marvel',175000000.00,'Yes','08/03/2019','Action','No'),
('The Lion King',175000000.00,'No','07/17/2019','Animation','Yes'),
('First Man',70000000.00,'Yes','08/29/2022','Adventure','Yes');

select mv_title as Title,mv.mv_budget as Budget,mv.mv_active as Active,mv.mv_date_of_launch as [Date Of Launch],mv.mv_genre as Genre,mv.mv_has_teaser as [Has Teaser] 
from movie as mv;

/*2.View Movie List Customer*/
select mv.mv_title as Title,mv.mv_budget as Budget,mv.mv_active as Active,mv.mv_date_of_launch as [Date Of Launch],mv.mv_genre as Genre,mv.mv_has_teaser as [Has Teaser]
from movie as mv 
where mv.mv_active = 'Yes' and mv.mv_date_of_launch > GETDATE();

/*3.Edit Movie*/
select mv.mv_title as Title,mv.mv_budget as Budget,mv.mv_active as Active,mv.mv_date_of_launch as [Date Of Launch],mv.mv_genre as Genre,mv.mv_has_teaser as [Has Teaser] 
from movie as mv 
where mv.mv_id = 1002;

update movie set 
mv_title = 'Black Widow',
mv_budget = 135000000.00,
mv_active = 'Yes',
mv_date_of_launch = '09/15/2023',
mv_genre = 'Action',
mv_has_teaser = 'Yes'
where mv_id = 1002;

/*4.Add to Favorite */
insert into [user] values ('Admin'),
('Customer');

insert into favorite values(2,1001),
(2,1002),
(2,1005);

/*5.View Favorite*/
select mv.mv_title as Title,mv.mv_active as Active,mv.mv_budget as Budget 
from movie as mv inner join favorite fv
on mv.mv_id = fv.fv_mv_id
where fv.fv_us_id = 2; 

select sum(mv.mv_budget) as Total
from movie as mv inner join favorite fv
on mv.mv_id = fv.fv_mv_id
where fv.fv_us_id = 2;  

/*6.Remove Movie from Favorite*/
delete from favorite where fv_us_id = 2 and fv_mv_id = 1002;