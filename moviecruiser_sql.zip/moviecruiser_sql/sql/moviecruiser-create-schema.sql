create database moviecruiser;
use moviecruiser;

create table [user](
	us_id bigint IDENTITY(1,1) NOT NULL,
	us_name varchar(100) NULL,
	CONSTRAINT PK_user PRIMARY KEY(us_id));

sp_help [user];

create table favorite(
	fv_id bigint IDENTITY(101,1) NOT NULL,
	fv_us_id bigint NULL,
	fv_mv_id bigint NULL,
	CONSTRAINT PK_favorite PRIMARY KEY(fv_id));

sp_help favorite;

create table movie(
	mv_id bigint IDENTITY(1001,1) NOT NULL,
	mv_title varchar(100) NULL,
	mv_budget decimal(12,2) NULL,
	mv_active varchar(3) NULL,
	mv_date_of_launch date NULL,
	mv_genre varchar(100) NULL,
	mv_has_teaser varchar(3) NULL,
	CONSTRAINT PK_movie PRIMARY KEY(mv_id));

alter table favorite ADD CONSTRAINT fv_us_id_fk FOREIGN KEY(fv_us_id) REFERENCES [user](us_id) on delete cascade on update cascade;
alter table favorite ADD CONSTRAINT fv_mv_id_fk FOREIGN KEY(fv_mv_id) REFERENCES movie(mv_id) on delete cascade on update cascade;

sp_help movie;

